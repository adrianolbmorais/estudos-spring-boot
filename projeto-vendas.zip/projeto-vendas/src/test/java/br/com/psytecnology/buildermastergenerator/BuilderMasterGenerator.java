package br.com.psytecnology.buildermastergenerator;

import br.com.psytecnology.domain.entity.ItemPedido;
import br.com.psytecnology.rest.dto.ItensPedidoDTO;
import buildermaster.BuilderMaster;

public class BuilderMasterGenerator {

    public static void main(String[] args) {
        new BuilderMaster().gerarCodigoClasse(ItemPedido.class);
    }
}
