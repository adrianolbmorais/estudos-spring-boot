package br.com.psytecnology.rest.dto;

import br.com.psytecnology.domain.entity.ItemPedido;
import br.com.psytecnology.domain.entity.Pedido;
import br.com.psytecnology.domain.entity.Produto;
import br.com.psytecnology.domain.repository.ProdutosRepository;
import br.com.psytecnology.exceptions.RegraNegocioException;

import java.util.List;

import static java.util.stream.Collectors.toList;

public class MapperDtoToEntity {

    private final ProdutosRepository produtosRepository;

    public MapperDtoToEntity(ProdutosRepository produtosRepository) {
        this.produtosRepository = produtosRepository;
    }

    public List<ItemPedido> converterItensPedidosDTOtoEntity(Pedido pedido, List<ItensPedidoDTO> itensPedidoDTO){

        if(itensPedidoDTO.isEmpty()){
            throw new RegraNegocioException("Não é possivel realizar um pedido sem itens");
        }

        return itensPedidoDTO.stream().map( dto -> {
            Integer idProduto = dto.getIdProduto();

            Produto produto = produtosRepository
                    .findById(idProduto)
                    .orElseThrow(
                            () -> new RegraNegocioException("Código de Produto inválido: " + idProduto)
                    );

            ItemPedido itemPedido = new ItemPedido();

            itemPedido
                    .quantidade(dto.getQuantidade())
                    .pedido(pedido)
                    .produto(produto);

            return itemPedido;

        }).collect(toList());

    }
}
