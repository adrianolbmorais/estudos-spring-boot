package br.com.psytecnology.domain.enums;

public enum StatusPedido {
    REALIZADO,
    CANCELADO;
}
