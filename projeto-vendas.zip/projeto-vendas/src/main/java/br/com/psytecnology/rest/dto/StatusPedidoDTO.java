package br.com.psytecnology.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusPedidoDTO {

    private String status;

}
