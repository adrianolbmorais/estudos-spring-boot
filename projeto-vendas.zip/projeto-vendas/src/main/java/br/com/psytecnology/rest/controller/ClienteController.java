package br.com.psytecnology.rest.controller;

import br.com.psytecnology.domain.entity.Cliente;
import br.com.psytecnology.domain.repository.ClientesRepository;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("api/clientes")
public class ClienteController {

    private static final String MENSAGEM_CLIENTE_NAO_ENCONTRADO = "Cliente não encontrado";

    private ClientesRepository clientesRepository;

    public ClienteController(ClientesRepository clientesRepository){
        this.clientesRepository = clientesRepository;
    }

    @GetMapping("/{idCliente}")
    public Cliente findProdutoById(@PathVariable Integer idCliente){
        return clientesRepository
                .findById(idCliente)
                .orElseThrow(
                        () -> new ResponseStatusException(HttpStatus.NOT_FOUND, MENSAGEM_CLIENTE_NAO_ENCONTRADO)
                );
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Cliente save(@RequestBody @Valid Cliente cliente){
        return clientesRepository.save(cliente);
    }

    @DeleteMapping("/{idCliente}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Integer idCliente){
        clientesRepository.findById(idCliente).map(
                cliente -> {
                    clientesRepository.delete(cliente);
                    return Void.TYPE;
                }).orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, MENSAGEM_CLIENTE_NAO_ENCONTRADO));
    }

    @PutMapping("/{idCliente}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void update(@PathVariable Integer idCliente, @RequestBody @Valid Cliente cliente){
        clientesRepository.findById(idCliente).map(
            clienteExistente -> {
                   cliente.setId(clienteExistente.getId());
                   clientesRepository.save(cliente);
                   return cliente;
            }
        ).orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, MENSAGEM_CLIENTE_NAO_ENCONTRADO));
    }

    @GetMapping
    public List<Cliente> findClienteAndFilter(Cliente cliente){
        ExampleMatcher matcher = ExampleMatcher
                                    .matching()
                                    .withIgnoreCase()
                                    .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        Example example = Example.of(cliente, matcher);
        return clientesRepository.findAll(example);
    }
}
